import json
from marshmallow import Schema, fields, ValidationError
from base64 import b64decode
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext

#class Reading(Schema):
#    humidity = fields.Number()
#    luminance = fields.Number()
#    moisture_1 = fields.Number()
#    moisture_2 = fields.Number()
#    moisture_3 = fields.Number()
#    pressure = fields.Number()
#    temperature = fields.Number()
#    voltage = fields.Number()
#
#class Map(Schema):
#    map = fields.Nested(Reading())

class Readings(Schema):
    timestamp = fields.Dict(keys=fields.String(), values=fields.DateTime())
    model = fields.Dict(keys=fields.String(), values=fields.String())
    readings = fields.Dict()
    nickname = fields.Dict(keys=fields.String(), values=fields.String())
    uid = fields.Dict(keys=fields.String(), values=fields.String())


logger = Logger(log_uncaught_exceptions=True)

@logger.inject_lambda_context(log_event=True)
def lambda_handler(event, LambdaContext) -> dict:
    print(event)
    logger.info({"operation": "Data Processing Lambda", "event": event})
    successes = 0 
    failures = 0

    records = event["records"]
    output = []
    for record in records:
        data = b64decode(record["data"])
        logger.info({"operation": "Data Processing Lambda", "data": data, "type": type(data)})
        formatted_data = data.decode('utf-8').replace("'", '"')
        logger.info({"operation": "Data Processing Lambda", "formatted data": formatted_data, "type": type(formatted_data)})
        try:
            result = Readings().loads(formatted_data)

            result_csv = (
                result["uid"]["S"] + "," + result["timestamp"]["S"] + "," + result["model"]["S"] + "," + result["nickname"]["S"] + "," +
                result["readings"]["M"]["humidity"] + "," +
                result["readings"]["M"]["luminance"] + "," +
                result["readings"]["M"]["pressure"] + "," +
                result["readings"]["M"]["temperature"] + "," +
                result["readings"]["M"]["moisture_1"] + "," +
                result["readings"]["M"]["moisture_2"] + "," +
                result["readings"]["M"]["moisture_3"] + "," +
                result["readings"]["M"]["voltage"]
            )

            logger.info({"operation": "Data Processing Lambda", "CSV Results": result_csv})
            successes += 1
            output.append({
                id: result["uid"],
                result: 'Ok',
                data:  result_csv
            })
        except ValidationError as error:
            failures += 1
            logger.info({"Validation Error": error})
            output.append({
                id: result["uid"],
                result: 'Failed',
                data:  json.loads(formatted_data)
            })

    logger.info(f"Processing Finished:  Successful Records: ${successes}, Failed Records: ${failures}")
    return output

